package com.xfcar.driver.model.bean;

public class SysUserDeptEntity {
	public int id; // 主键ID
	public int deptId; // 部门ID
	public int userId; // 用户ID
}
