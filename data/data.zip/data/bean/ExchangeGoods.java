package com.xfcar.driver.model.bean;

public class ExchangeGoods {
	public String userId; // 用户ID
	public String goodsName; // 兑换商品名称
}
