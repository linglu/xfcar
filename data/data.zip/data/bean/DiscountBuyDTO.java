package com.xfcar.driver.model.bean;

public class DiscountBuyDTO {
	public int id; // 主键ID
	public int userId; // 用户ID
	public String discountCode; // 套餐编码
	public String pageSize; // 页码（默认10）
	public String pageNumber; // 页数（默认1）
}
