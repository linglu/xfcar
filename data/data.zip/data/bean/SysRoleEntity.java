package com.xfcar.driver.model.bean;

public class SysRoleEntity {
	public int roleId; // 角色ID
	public String roleName; // 角色名称
	public String roleCode; // 角色编码
	public String roleDesc; // 角色描述
	public String createTime; // 创建时间
	public String updateTime; // 修改时间
	public String delFlag; // 删除标识（0-正常,1-删除）
}
