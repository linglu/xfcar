package com.xfcar.driver.model.bean;

public class PasswordVO {
	public int userId; // 用户ID
	public String mobile; // 手机号
	public String type; // 类型
	public String messageCode; // 短信验证码
	public String mailCode; // 邮箱验证码
	public String oldPassword; // 旧密码
	public String newPassword; // 新密码
	public String validateCode; // 验证码
}
