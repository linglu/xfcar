package com.xfcar.driver.model.bean;

public class ContactDTO {
	public int userId; // 用户ID
	public String contactName; // 紧急联系人
	public String contactMobile; // 紧急联系人手机号
}
