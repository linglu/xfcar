package com.xfcar.driver.model.bean;

public class IntegralGoodsVo {
	public int userId; // 用户ID
	public String goodsTag; // 礼品标签
}
